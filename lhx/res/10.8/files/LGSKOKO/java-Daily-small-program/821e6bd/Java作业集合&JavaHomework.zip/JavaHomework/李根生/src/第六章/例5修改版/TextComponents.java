package ������.��5�޸İ�;

import java.awt.*;
import javax.swing.*;

public class TextComponents extends JFrame {

	public TextComponents(){
		
		super("�ı��к��ı���");
		this.setBounds(100, 100, 350, 125);
		this.setResizable(false);
//		this.setLayout(new )
		
		JPanel jp = new JPanel();
		jp.setLayout(new GridLayout(3,1) );
		this.add(jp,"West");
		JLabel j = new JLabel("user");
		j.setSize(10, 10);
		jp.add(j);
		jp.add(new JLabel("password"));
		jp.add(new JLabel("descriptation") );
		
		JPanel jp2 = new JPanel();
		jp2.setLayout(new GridLayout(3,1) );
		this.add(jp2,"East");
		JTextField jtf = new JTextField(10);
		jtf.setSize(10, 1);
		jp2.add(jtf);
		jp2.add(new JPasswordField(20));
		jp2.add(new JTextArea("function",5,10));
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
		
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new TextComponents();
	}

}
