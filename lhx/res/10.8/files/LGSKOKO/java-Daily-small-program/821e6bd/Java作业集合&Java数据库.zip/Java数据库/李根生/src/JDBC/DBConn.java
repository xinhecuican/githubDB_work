package JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class DBConn {
	
	String driverName = "com.mysql.cj.jdbc.Driver";
	String url = "jdbc:mysql://localhost:3306/student?useSSL=true";
	String userName = "root";
	String passWord = "420422844";
	Connection conn =null;
	Statement stmt = null;
	ResultSet rs = null;
	
	public DBConn(){
		
		try {
				Class.forName(driverName);
				conn = DriverManager.getConnection(url,userName,passWord);
				System.out.println(conn);
				
				stmt = conn.createStatement();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public ResultSet executeQury(String sql){
		
		  try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println("�����쳣��"+e.getMessage());
			System.err.println("�쳣��SQL���"+sql);
		}
		  
		  return rs;
	}
	
	public int executeUpdate(String sql){
		
		int rowCount = 0;
		try {
			rowCount = stmt.executeUpdate(sql);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println("�����쳣��"+e.getMessage());
			System.err.println("�쳣��SQL���"+sql);
		}
		
		return rowCount;
	}
	
	public void close()
	{
		
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn = null;
	}
}
