package Test;
import java.sql.*;

import JDBC.DBConn;
public class StudentTest {

	public static void main(String[] args)
	{
		DBConn db = new DBConn();
		Student stu = new Student();
		String sql2 = "SELECT * from student";
		ResultSet rs = db.executeQury(sql2);
		
		try {
			while(rs.next())
			{
				
				stu.setId(rs.getInt("Id"));
				stu.setName(rs.getString("N"));
				stu.setAge(rs.getInt("Age"));
				System.out.println(stu);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		
		db.close();
		
	}
	
	
}
