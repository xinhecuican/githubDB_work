import java.awt.Desktop;
import java.net.URI;


public class DeskTopTest {

	private static Desktop desktop;
	
	public static void browse(){
		
		if(Desktop.isDesktopSupported()){
			desktop = Desktop.getDesktop();
			try{
				//URIָ��ҳ���ַ
				desktop.browse(new URI("https://blog.csdn.net/qq_41998273/article/details/86765914"));
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		browse();
	}

}
