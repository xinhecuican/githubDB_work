package ����.��ҵ1;

public class Action {
   
	private Computer aComputer;
	private Projector aProjector;
	private Screen aScreen;
	
	
	public Computer getaComputer() {
		return aComputer;
	}



	public void setaComputer(Computer aComputer) {
		this.aComputer = aComputer;
	}



	public Projector getaProjector() {
		return aProjector;
	}



	public void setaProjector(Projector aProjector) {
		this.aProjector = aProjector;
	}



	public Screen getaScreen() {
		return aScreen;
	}



	public void setaScreen(Screen aScreen) {
		this.aScreen = aScreen;
	}



	public void action(){
		
		 aComputer.processData();
		 aComputer.transferData();
		 
		 aProjector.receiveData();
		 aProjector.projectData();
		 
		 aScreen.displayData();
		
	}
}
