package ����.��ҵ1;

public class Client {

	
	public static void main(String[] args) {
		
		Action aAction;
		Computer pingguodiannao;
		Projector huiputouyingyi;
		Screen sanxingpingmu;


		aAction = new Action();
		pingguodiannao = new Computer();
		huiputouyingyi = new Projector();
		sanxingpingmu = new Screen();
		

		aAction.setaComputer(pingguodiannao);
		aAction.setaProjector(huiputouyingyi);
		aAction.setaScreen(sanxingpingmu);
		
		pingguodiannao.setData("����");
		huiputouyingyi.setData("��������");
		sanxingpingmu.setData("ͶӰ����Ϣ");
		
		aAction.action();
		

	}

}
