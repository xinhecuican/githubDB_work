package ����.��ҵ1;

public class Screen {

	private String data;

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}
	
	public void displayData(){
		
		if(this.data=="ͶӰ����Ϣ");
		System.out.println("��Ļ��ʾ"+this.data);
		
	}
	

}
