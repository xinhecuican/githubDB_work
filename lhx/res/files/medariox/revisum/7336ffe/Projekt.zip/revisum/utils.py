from pathlib import Path
from github import Github


gh_access_token = ''
gh_username = ''
gh_password = ''


def get_project_root():
    """Returns project root folder."""
    return Path(__file__).parent


def gh_session():
    """Returns a PyGithub session."""
    if gh_access_token:
        return Github(gh_access_token)
    elif gh_username and gh_password:
        return Github(gh_username, gh_password)

    return Github()
